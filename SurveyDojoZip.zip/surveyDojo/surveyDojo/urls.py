from django.urls import path, include          

urlpatterns = [
    path('', include('vicSurveyApp.urls')),	   

]
