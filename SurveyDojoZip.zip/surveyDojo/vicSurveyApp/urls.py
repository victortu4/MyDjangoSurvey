from django.urls import path     
from . import views
urlpatterns = [
    path("", views.SurveyPage),	
    path("orderDonuts", views.orderDonuts )
]