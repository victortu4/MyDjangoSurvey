from django.apps import AppConfig


class VicsurveyappConfig(AppConfig):
    name = 'vicSurveyApp'
