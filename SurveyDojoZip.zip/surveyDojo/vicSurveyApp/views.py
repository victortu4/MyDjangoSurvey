from django.shortcuts import render, HttpResponse, redirect
def SurveyPage(request):
    return render(request,"index.html")

def orderDonuts(request):
    print("*" * 20)
    print(request.method)
    

    print("PRINTING REQUEST.POST (INFO COLLECTED FROM THE FORM) BELOW")
    print(request.POST)


    context = {
        'nameOfCust': request.POST['customerName'],
        'textInfo': request.POST['info'],
        'selectFlavor': request.POST['Flavors'],
        'selectQuantity': request.POST["Quantity"]
    }

    return render(request, "show.html", context)

